django-lc - django application containing common LC bits
========================================================

django application for dealing with common LC templates, static
resource (css, images), ...


Features
--------

* base template 

* static resources


Installation
------------

You can install django-lc with the command::

  $ pip install git@git.rdc.lctl.gov:django-lc.git#egg=django-lc

and the prerequisites::

  $ pip install django-staticfiles


Example usage
-------------

add the following bits to your settings.py::

  INSTALLED_APPS += (
      'lc',
      'django.contrib.staticfiles',
  )

  STATIC_URL = "/static/"

in your urls.py::

  url(r'^static/(?P<path>.*)$', 'staticfiles.views.serve'),

in your templates::

{% extends "lc/base.html" %}


Source
------

git@git.rdc.lctl.gov:django-lc.git
