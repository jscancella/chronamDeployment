import os
from distutils.core import setup


def is_package_data(package, path):
    return path in ["static", "templates"]


def find_package_data(packages):
    data = {}
    for root, dirnames, filenames in os.walk("."):
        parts = root.split(os.sep)
        if len(parts)<2:
            continue
        pkg = parts[1]
        if pkg in packages:
            file_list = data.setdefault(pkg, [])
            if len(parts)>2 and is_package_data(pkg, parts[2]):
                nroot = os.sep.join(parts[2:])
                for filename in filenames:
                    file_list.append(os.path.join(nroot, filename))
    return data


setup(name='django-lc',
      version="1.0.1",
      description='',
      author='',
      author_email='',
      url='',
      download_url='',
      packages=['lc', ],
      package_data=find_package_data(['lc']),
      zip_safe=False,
      )
